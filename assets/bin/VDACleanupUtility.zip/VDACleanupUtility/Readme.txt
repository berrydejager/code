* Services *
The following services are stopped and removed, if they are available:

BrokerAgent
CitrixCscEngine
CitrixUSB
CitrixPvD
CitrixRdR
CitrixRedirector
CitrixEncryptionService
CitrixEUEM
CitrixCseEngine
CitrixTelemetryService
CtxAudioSrv
CtxFlashSvc
CtxSmartCardSvc
CtxSCardCertPropSvc
CtxSCardRemovalPolicySvc
CtxMultiTouchSvc
CtxSensVcSvc
ctxProfile
cpsvc
MRVCSvc
PicaDvcControllerSvc
PorticaService
PvsVmAgent
ServicesManager
StackControlService
WorkstationAgent
CtxAudioSvc
CitrixUpgradeAgent
CdfCaptureService
CitrixVDACeipService
CitrixUWACacheService
CtxHdxWebSocketService
CtxBrowserSvc
CtxRaveSvc
CtxPortFwdSvc
CtxTeamsSvc
CtxLocalUserSrv
CtxNsapSvc
CtxWIASvc
CtxIcaCtlsSvc
CtxGDTSvc
CtxFidoMux
CtxDNDSvc
CtxCertManagerSvc
CtxClxMtpSvc

* Drivers *
The utility ensures the following drivers are removed and not operational, if they are available:

mirror
monblanking
CtxAd
ctxsmcdrv
ctxusbb
icareduc
icatdwsk
pdcrypt1
pdcrypt2
pdrframe
picacdd
picadd
picadm
picakbf
Picakbm
picamouf
picapar
picaser
picatwcomms
picavc
tdcgp
twexport
vbdenum
vbdfilt
vd3d
wdica
ivm
ivmBoot
IvmPnP
IvmVhd
thinwire
ThinwireMirror
ctxdvcs
ctxmthid
icausbb
tdica
thinwiremirror2
upmjit
ctxpn
icappexport
TdWsk
Tdhtml5
cdfdrv
citrixupd
CtxMcsWbc
DAFsFilter
ctxUvi
CVhdFilter

* Files and Directories *
The utility deletes the following files and directories if they are available:

%programfiles%\Citrix\ICAService
%programfiles%\Citrix\printer
%programfiles%\Citrix\System32
%programfiles%\Citrix\VirtualDesktopAgent
%programfiles%\Citrix\XenDesktopVdaSetup
%programfiles%\Citrix\GroupPolicy
%programfiles%\Citrix\PvsVm
%programfiles%\Citrix\ThirdPartyIntegration
%programfiles%\Citrix\personalvDisk
%programfiles%\Citrix\HDX
%programfiles%\Citrix\TelemetryService
%programfiles%\Citrix\ICAConfigTool
%programfiles%\Citrix\ImageAnalysis
%programfiles%\Citrix\UniversalPrintClient
%programfiles%\Citrix\UserProfileManager
%programfiles%\Citrix\EnhancedDesktopExperience
%programfiles%\Citrix\Euem
%programfiles%\Citrix\VirtualSmartCard
%programfiles%\Citrix\MCS IO
%programfiles%\Citrix\CitrixUpgradeAgent
%programfiles%\Citrix\CdfCaptureService
%programfiles%\Common Files\Citrix\Licensing
%programfiles%\Common Files\Citrix\System32\Resource
%programfiles%\Common Files\Citrix\System32\Firefox_Extension
%programfiles%\Common Files\Citrix\System32\Chrome_Extension
%programfiles%\Common Files\Citrix\System32\picaProvider.dll
%programfiles%\Common Files\Citrix\System32\CCtxExceptionHandler.exe
%programfiles%\Common Files\Citrix\System32\CCtxExceptionHandler64.exe
%programfiles%\Common Files\Citrix\System32\CtxExceptionHandler.dll
%programfiles%\Common Files\Citrix\System32\CtxExceptionHandler64.dll
%programfiles%\Common Files\Citrix\System32\CtxExceptionHandlerEventLogResources.dll
%programfiles%\Common Files\Citrix\System32\CtxExceptionHandlerEventProvider.man
%programfiles%\Common Files\Citrix\System32\npVDAURLInterceptorPlugin.dll
%programfiles%\Common Files\Citrix\System32\VDAIEInterceptor.dll
%programdata%\citrix\Diagnostics
%programdata%\citrix\GroupPolicy
%programdata%\citrix\personalvDisk
%programdata%\citrix\CTQs
%programdata%\CitrixCseCache
%systemroot%\inf\CitrixICA
%systemroot%\System32\drivers\CtxUvi.sys
%systemroot%\System32\drivers\Msft_Kernel_ctxusbb_01007.Wdf
%systemroot%\System32\drivers\ctxad.sys
%systemroot%\System32\drivers\ctxusbb.sys
%systemroot%\System32\drivers\picadd.sys
%systemroot%\System32\drivers\icareduc.sys
%systemroot%\System32\drivers\pdcrypt1.sys
%systemroot%\System32\drivers\pdcrypt2.sys
%systemroot%\System32\drivers\pdrframe.sys
%systemroot%\System32\drivers\twexport.sys
%systemroot%\System32\drivers\wdica.sys
%systemroot%\System32\drivers\picakbf.sys
%systemroot%\System32\drivers\picamouf.sys
%systemroot%\System32\drivers\picadm.sys
%systemroot%\System32\drivers\picapar.sys
%systemroot%\System32\drivers\picaser.sys
%systemroot%\System32\drivers\picaTwComms.sys
%systemroot%\System32\drivers\picavc.sys
%systemroot%\System32\drivers\ctxsmcdrv.sys
%systemroot%\System32\drivers\icatdwsk.sys
%systemroot%\System32\drivers\TdCgp.sys
%systemroot%\System32\drivers\vd3dk.sys
%systemroot%\System32\drivers\picacdd.sys
%systemroot%\System32\drivers\picakbm.sys
%systemroot%\System32\drivers\IvmVhd.sys
%systemroot%\System32\drivers\ivm.sys
%systemroot%\System32\drivers\ivmBoot.sys
%systemroot%\System32\drivers\IvmPnp.sys
%systemroot%\System32\drivers\ctxpn.sys
%systemroot%\System32\drivers\CTXDVCS.sys
%systemroot%\System32\drivers\icappexport.sys
%systemroot%\System32\drivers\TdIca.sys
%systemroot%\System32\drivers\upmjit.sys
%systemroot%\System32\drivers\icausbb.sys
%systemroot%\System32\drivers\monblanking.sys
%systemroot%\System32\drivers\vbdenum.sys
%systemroot%\System32\drivers\WpdUpFltr.sys
%systemroot%\System32\drivers\CtxUvi.sys
%systemroot%\System32\drivers\CtxMcsWbc.sys
%systemroot%\System32\drivers\DAFsFilter.sys
%systemroot%\System32\drivers\vdodk.sys
%systemroot%\System32\resource\de\icaperfUI.dll
%systemroot%\System32\resource\en\icaperfUI.dll
%systemroot%\System32\resource\es\icaperfUI.dll
%systemroot%\System32\resource\fr\icaperfUI.dll
%systemroot%\System32\resource\ja\icaperfUI.dll
%systemroot%\System32\resource\zh-cn\icaperfUI.dll
%systemroot%\System32\spool\drivers\W32X86\3\Cpupdui.dll
%systemroot%\System32\spool\drivers\W32X86\3\Cpxpsupdui.dll
%systemroot%\System32\spool\drivers\x64\3\CitrixUpd.txt
%systemroot%\System32\spool\drivers\x64\3\CitrixXps.txt
%systemroot%\System32\spool\drivers\x64\3\CitrixXpsDrv-PipelineConFig.xml
%systemroot%\System32\spool\drivers\x64\3\upprn.dll
%systemroot%\System32\spool\drivers\x64\3\Cpupdui.dll
%systemroot%\System32\spool\drivers\x64\3\Cpxpsupdui.dll
%systemroot%\System32\spool\drivers\x64\3\Cpupdrv.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_de.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_en.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_es.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_fr.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_ja.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_zh-CN.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_ko.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_zh-TW.dll
%systemroot%\System32\spool\drivers\x64\3\Cupdres_ru.dll
%systemroot%\System32\spool\prtprocs\x64\cpproc.dll
%systemroot%\System32\wbem\Framework\root\citrix\VdaParameters
%systemroot%\System32\wbem\Framework\root\citrix\EUEM
%systemroot%\SysWOW64\wbem\Framework\root\citrix\ICAService
%systemroot%\SysWOW64\wbem\Framework\root\citrix\VdaParameters
%systemdrive%\users\CitrixTelemetryService
%systemdrive%\users\*\Appdata\Roaming\Microsoft\Windows\StartMenu\Programs\Citrix\UpdatepersonalvDisk.lnk
%systemdrive%\users\*\Citrix\GroupPolicy
%systemroot%\System32\spool\drivers\x64\PCC\citrixupd.inf_amd64_3dd12fd41c295268.cab
%systemroot%\SysWOW64\ctxhkcs.dll
%systemroot%\System32\ctxhkcs.dll
%systemroot%\System32\CtxKerbProvider.dll
%systemroot%\System32\icaendpoint.dll
%systemroot%\System32\vdtw30.dll
%systemroot%\System32\icardd.dll
%systemroot%\SysWOW64\icaendpoint.dll

*  Registry KEys *
The folowing keys are removed if they are in the registry:

HKLM\SOFTWARE\Citrix\Audio
HKLM\SOFTWARE\Citrix\CitrixDesktopDeliveryController
HKLM\SOFTWARE\Citrix\CitrixVirtualDesktopAgent
HKLM\SOFTWARE\Citrix\Configuration
HKLM\SOFTWARE\Citrix\CtxExceptionHandler
HKLM\SOFTWARE\Citrix\ClientHostedApps
HKLM\SOFTWARE\Citrix\CtxBackupKey
HKLM\SOFTWARE\Citrix\CtxHook
HKLM\SOFTWARE\Citrix\Director
HKLM\SOFTWARE\Citrix\FileTransfer
HKLM\SOFTWARE\Citrix\Graphics
HKLM\SOFTWARE\Citrix\GroupPolicy
HKLM\SOFTWARE\Citrix\HDXMediaStream
HKLM\SOFTWARE\Citrix\HdxMediaStreamForFlash
HKLM\SOFTWARE\Citrix\Ica
HKLM\SOFTWARE\Citrix\ImageAnalysis
HKLM\SOFTWARE\Citrix\MachineIdentityServiceAgent
HKLM\SOFTWARE\Citrix\personalvDisk
HKLM\SOFTWARE\Citrix\PortICA
HKLM\SOFTWARE\Citrix\Print
HKLM\SOFTWARE\Citrix\Roles
HKLM\SOFTWARE\Citrix\ServerFTA
HKLM\SOFTWARE\Citrix\SmartCard
HKLM\SOFTWARE\Citrix\StackAgentInfo
HKLM\SOFTWARE\Citrix\Telemetry
HKLM\SOFTWARE\Citrix\UniversalPrintDrivers
HKLM\SOFTWARE\Citrix\CitrixUpgradeAgent
HKLM\SOFTWARE\Citrix\CdfCaptureService
HKLM\SOFTWARE\Citrix\Versions
HKLM\SOFTWARE\Citrix\XenDesktop
HKLM\SOFTWARE\Citrix\Vd3d
HKLM\SOFTWARE\Citrix\Versions\CitrixVirtualDesktopAgent
HKLM\SOFTWARE\Citrix\VirtualDesktopAgent
HKLM\SOFTWARE\Citrix\XDMISAgent
HKLM\SOFTWARE\Citrix\Install\BrokerAgent
HKLM\SOFTWARE\Citrix\Install\TelemetryService
HKLM\SOFTWARE\Citrix\Install\ICAWS

HKLM\SOFTWARE\Citrix\XenDesktop
HKLM\SOFTWARE\Policies\Citrix
HKU\*\Software\Citrix\ICA
HKU\*\Software\Citrix\PortICA
HKU\*\Software\Citrix\Shell
HKU\*\Software\Citrix\WFSHELL
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\001464AD5142F1745AE23624EAD9C9CD
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\2CF1140350D9EF34D9580A3FDBBD3D60
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\6B7C92B53F03F894EB65CB13DF3E3F06
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\F780AC5C27AB1A144A961E73CE5BD4E2
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\291F26F9BF0E51646A68DB974DE09807
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\16D558C01B532514B9C60B335CFDEB13
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\23FD0BC2640812E4B860EFD205EBDA9B
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\38F3545F87C25F04AB63151B632057F8
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\3FDB0A67E8A82D74E8242BFB52C5CF8C
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\45A0244DCE9C48E4CB0A12106C284AFD
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\45E58DCBEB0533C448BBB3826A0D1F89
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\46AD1BD00A03E074EAC0CC94466729C6
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\6680E49B0BF8BAA49AF25F1604A6D5AD
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\A0C61A76797FD414BAD80C18C8D85EF1
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\ACDC5FAB40DE6DF41BCC33FBFEEAB3E5
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\BAA9EABDE76187A49A2AE8FAB0A46EE7
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\BB4E73690C2AFA34E886C1F3FD1FA885
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\FE6D25EF2736D95458578BA49CD8428B
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\09AE9D2456C8EF64B9B420B629FD37BE
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\10E1E6E266A403641833843FEA959E7B
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\2CFC9683963AE7544A8AB14DF7A995B2
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\7651814B108F0E94298D512689EAFE72
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\88ADFB28E3D505F49AC3A2BB3F6EB023
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\BD20619387819704CAE7EDF584DA9728
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\032D629EBFD8AC746BA14DC51C830B32
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\13B0A586B77C146448EF5EA818563F71
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\AC88215A9359C554C8CFE6C9DFF1B3FE
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\4E329C7D814A72C4587E7B9EF76955CF
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\67CFD30744A94A440951648481D1E9AF
HKLM\SOFTWARE\Classes\Installer\UpgradeCodes\7F4BA9FF36302274F876EC3592D7B275
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\1E29547C6992AE340B9A9A212CD19F1D
HKCU\Software\Microsoft\Installer\UpgradeCodes\291F26F9BF0E51646A68DB974DE09807
HKCU\Software\Microsoft\Installer\Products\3AC2676344E6C654DA1DBA9F19490861

HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\001464AD5142F1745AE23624EAD9C9CD
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\2CF1140350D9EF34D9580A3FDBBD3D60
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\6B7C92B53F03F894EB65CB13DF3E3F06
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\F780AC5C27AB1A144A961E73CE5BD4E2
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\291F26F9BF0E51646A68DB974DE09807
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\16D558C01B532514B9C60B335CFDEB13
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\23FD0BC2640812E4B860EFD205EBDA9B
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\38F3545F87C25F04AB63151B632057F8
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\3FDB0A67E8A82D74E8242BFB52C5CF8C
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\45A0244DCE9C48E4CB0A12106C284AFD
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\45E58DCBEB0533C448BBB3826A0D1F89
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\46AD1BD00A03E074EAC0CC94466729C6
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\6680E49B0BF8BAA49AF25F1604A6D5AD
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\A0C61A76797FD414BAD80C18C8D85EF1
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\ACDC5FAB40DE6DF41BCC33FBFEEAB3E5
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\BAA9EABDE76187A49A2AE8FAB0A46EE7
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\BB4E73690C2AFA34E886C1F3FD1FA885
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\FE6D25EF2736D95458578BA49CD8428B
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\09AE9D2456C8EF64B9B420B629FD37BE
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\10E1E6E266A403641833843FEA959E7B
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\2CFC9683963AE7544A8AB14DF7A995B2
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\7651814B108F0E94298D512689EAFE72
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\88ADFB28E3D505F49AC3A2BB3F6EB023
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\BD20619387819704CAE7EDF584DA9728
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\032D629EBFD8AC746BA14DC51C830B32
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\13B0A586B77C146448EF5EA818563F71
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\AC88215A9359C554C8CFE6C9DFF1B3FE
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\4E329C7D814A72C4587E7B9EF76955CF
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\67CFD30744A94A440951648481D1E9AF
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UpgradeCodes\7F4BA9FF36302274F876EC3592D7B275
HKLM\SYSTEM\CurrentControlSet\Control\Citrix
HKLM\SYSTEM\ControlSet001\Control\Citrix
HKLM\SYSTEM\ControlSet002\Control\Citrix
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\CitrixVirtualDesktopAgent
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{AA1B1D2B-D687-4910-94D5-21A33E92399F}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{CA161BBE-D405-458e-B5C4-EEE681C19514}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{1D7BE727-4560-4adf-9ED8-5EEC78C6ECFF}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{5B340FA8-5C3F-45de-87C8-487ABE91013E}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{6D050C58-74E0-40f0-87F6-FDD115B589F8}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{81C8E4DC-B376-4D88-BCCD-BD0DD65BEE2B}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviders\{F8A0B131-5F68-486c-8040-7E8FC3C85BB6}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviderFilters\{FF525C75-290A-411A-98B6-2729537D6F38}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\CredentialProviderFilters\{2B7BFBB8-958F-4c64-9282-DAAB592D28B8}
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Winlogon\GPExtensions\{0D0C7034-2EBD-4A87-A9B9-9015E3F2E6E0}
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Winlogon\GPExtensions\{26F29E43-DA55-459d-A045-5FEB25F8AB15}
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Print\PackageInstallation\WindowsNTx86\DriverPackages\citrixupd.inf_x86_neutral_b01510aaf1749eb1
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Print\PackageInstallation\Windowsx64\DriverPackages\citrixupd.inf_amd64_neutral_b01510aaf1749eb1
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Print\PackageInstallation\WindowsNTx86\DriverPackages\citrixupd.inf_x86_3f96f60ffa296838
HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Print\PackageInstallation\Windowsx64\DriverPackages\citrixupd.inf_amd64_3f96f60ffa296838
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\WindowsNTx86\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Environments\Windowsx64\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\ControlSet001\Control\Print\Providers\ClientPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Providers\UniversalPrinter
HKLM\SYSTEM\ControlSet001\Control\Print\Monitors\ClientPrinterPort
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\WindowsNTx86\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Environments\Windowsx64\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\ControlSet002\Control\Print\Providers\ClientPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Providers\UniversalPrinter
HKLM\SYSTEM\ControlSet002\Control\Print\Monitors\ClientPrinterPort
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\WindowsNTx86\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\WindowsNTx86\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixUniversalPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windowsx64\Drivers\Version-3\CitrixXPSUniversalPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windowsx64\PrintProcessors\CitrixPrintProcessor
HKLM\SYSTEM\CurrentControlSet\Control\Print\Providers\ClientPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Providers\UniversalPrinter
HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\ClientPrinterPort
HKLM\SOFTWARE\Classes\CLSID\{0BB94541-4EB9-4134-B201-E1E33B78DEE6}
HKLM\SOFTWARE\Classes\CLSID\{19726646-F912-4029-85E2-8799F4F145CA}
HKLM\SOFTWARE\Classes\AppID\CtxAudioCodec.DLL
HKLM\SOFTWARE\Classes\AppID\CtxVideoCodec
HKLM\SOFTWARE\Classes\AppID\PicaSvc2.exe
HKLM\SOFTWARE\Classes\AppID\{9B100B28-6491-4c8f-83A1-AA64BB64E206}
HKLM\SOFTWARE\Classes\AppID\{C481B12A-93FC-4D68-9BCD-B68144CC4265}
HKLM\SOFTWARE\Classes\TypeLib\{0C860399-91FC-47E1-9C16-F42FB139A7EB}
HKLM\SOFTWARE\Classes\TypeLib\{ED12AC15-638A-40FB-9B58-E2B2C290ED08}
HKLM\SOFTWARE\Classes\Wow6432Node\AppID\{9B100B28-6491-4c8f-83A1-AA64BB64E206}
HKLM\SOFTWARE\Classes\Wow6432Node\AppID\{C481B12A-93FC-4D68-9BCD-B68144CC4265}
HKLM\SOFTWARE\Classes\Wow6432Node\AppID\CtxVideoCodec
HKLM\SOFTWARE\Classes\Wow6432Node\AppID\PicaSvc2.exe
HKLM\SOFTWARE\Classes\Wow6432Node\TypeLib\{0C860399-91FC-47E1-9C16-F42FB139A7EB}
HKLM\SOFTWARE\Classes\Wow6432Node\TypeLib\{ED12AC15-638A-40FB-9B58-E2B2C290ED08}
HKLM\System\CurrentControlSet\Control\GraphicsDrivers\Configuration\CTX0466HVLQ803101_21_07D8_9A^C880D32C75A7FBDFE82EB2A99C1AF027
HKLM\System\CurrentControlSet\Control\GraphicsDrivers\Connectivity\CTX0466HVLQ803101_21_07D8_9A^C880D32C75A7FBDFE82EB2A99C1AF027
HKLM\System\CurrentControlSet\services\CitrixICA
HKLM\System\CurrentControlSet\services\CitrixUserProfileManager
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DIFx\DriverStore\CtxMcsWbc_684EA28F0E1D1E834BC1BE5B9ECC55A61601C726
HKLM\SYSTEM\CurrentControlSet\Control\Citrix\PvsVmBoot
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{171af5ae-5ed4-41e1-8f4d-de1aa2a0d9be}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{1b9f82cb-cdcb-420b-8817-c9ab8a23167c}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{6c3b1017-ffcd-45d5-9a5d-0d413322aa38}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{b52c0ff2-e2ad-45c2-8c66-016031018587}
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{c6d0a271-2e59-40cd-b451-9000a9f104f9}
HKCU\Software\Microsoft\Installer\UpgradeCodes\291F26F9BF0E51646A68DB974DE09807
HKCU\Software\Microsoft\Installer\Products\3AC2676344E6C654DA1DBA9F19490861

The subkeys\values under "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall" and "HKLM\Software\Microsoft\Windows\CurrentVersion\Installer\UserData" 
are removed if they are in the registry

Citrix Director VDA Plugin
Citrix Monitor Service VDA Plugin
Citrix Group Policy Client-Side
Machine Management WMI Provider
Citrix Virtual Desktop Agent
Citrix Personalization AppV - VDA
Citrix WMI Proxy Plugin
Citrix HDX WS
Machine Identity Service Agent
Citrix personal vDisk
Citrix Profile management
Citrix Universal Print Client

The subkeys\values under "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" are removed if they are in the registry

vDesk VDI
Citrix PortICA User Agent
Citrix Sensor And Location Registration
Citrix UPM UserMsg
Citrix Time Zone Restore
